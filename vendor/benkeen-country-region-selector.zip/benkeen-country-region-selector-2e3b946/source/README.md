## Country-Region-Selector - source

This folder contains the raw source for the country-region-selector script. Up until 0.1.7 this folder contained
the actual dev code. Now they've been moved to the dist folder. This folder now contains the raw code, which is 
used to generate the files in /dist via `grunt generate`.
